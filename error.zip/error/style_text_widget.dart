import 'package:flutter/material.dart';

//Another Custom widget- Style Text Widget
class StyleTextWidget extends StatelessWidget {
//Own Constructor function with super key and positional  argumnet
  //const StyleTextWidget(String text, {super.key}) : outputText = text;
  const StyleTextWidget(this.text, {super.key});
  //class variable(property)
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(text,
        style: const TextStyle(
          color: Colors.blueAccent,
          fontSize: 28.0,
        ));
  }
}
