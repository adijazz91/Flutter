import 'package:flutter/material.dart';
//import 'package:first_app/style_text_widget.dart';

const startAlignment = Alignment.topLeft;
const endAlignment = Alignment.bottomRight;

// //Building Custom Widgets
// class GradientContainer extends StatelessWidget {
//   //Own Constructor function //super class and names argumnet(which are optional by default so use required)
//   const GradientContainer({super.key, required this.colors});

//   final List<Color> colors;

//   @override
//   Widget build(context) {
//     return Container(
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             colors: colors,
//             begin: startAlignment,
//             end: endAlignment),
//         ),
//         child: const Center(
//           child: StyleTextWidget('Dynamic text'),
//         ));
//   }
// }

//Alternative approach
//Building Custom Widgets
class GradientContainer extends StatelessWidget {
  const GradientContainer(this.color1, this.color2, {super.key});
  //we can have multiple constructor
  // const GradientContainer.purple({super.key})
  // : color1 = Colors.deepOrangeAccent,
  //   color2 = Colors.indigo

  final Color color1;
  final Color color2;

  @override
  Widget build(context) {
    return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [color1, color2],
              begin: startAlignment,
              end: endAlignment),
        ),
        child: Center(
          child: Image.asset('images/dice-2.png'),
          //StyleTextWidget('Dynamic text'),
        ));
  }
}
